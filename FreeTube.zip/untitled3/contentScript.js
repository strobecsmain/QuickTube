function replaceYouTubeIcon() {
    const newIconURL = chrome.runtime.getURL("icons/newyt.svg");

    const targetElement = document.querySelector('span.yt-icon-shape yt-spec-icon-shape div svg#yt-logo-updated-svg_yt1');

    if (targetElement) {
        const imgElement = document.createElement('img');
        imgElement.src = newIconURL;
        imgElement.style.width = "100%";
        imgElement.style.height = "100%";

        targetElement.parentElement.replaceChild(imgElement, targetElement);
    }
}

document.addEventListener("DOMContentLoaded", replaceYouTubeIcon);
